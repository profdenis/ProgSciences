import csv

ligne1 = [3, 6, 2, 8, 1]
ligne2 = [1, 7, -2, -12, 14]
ligne3 = [1, 2, 3, 4, 5]

lignes = [ligne1, ligne2, ligne3]

with open('donnees4.csv', 'w') as fichier:
    for l in lignes:
        for x in l[:-1]:
            fichier.write(f"{x},")
        fichier.write(f"{l[-1]}\n")


with open("donnees4.csv", "r") as fichier:
    lecteur = csv.reader(fichier)
    for ligne in lecteur:
        print(ligne)

